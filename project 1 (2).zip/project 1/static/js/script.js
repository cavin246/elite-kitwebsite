// Mobile Navigation Toggle
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');

if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        
        // Animate hamburger icon
        const bars = navToggle.querySelectorAll('.bar');
        bars.forEach(bar => bar.classList.toggle('active'));
    });
}

// Close mobile menu when clicking on a link
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
    });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Form handling (static - no actual submission)
const contactForm = document.querySelector('.form');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Thank you for your message! This is a static demo - no message was actually sent.');
        contactForm.reset();
    });
}

// Add hover effects to jersey items
const jerseyItems = document.querySelectorAll('.jersey-item, .jersey-card');
jerseyItems.forEach(item => {
    item.addEventListener('mouseenter', function() {
        this.style.transition = 'all 0.3s ease';
    });
});

// Header scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(26, 26, 46, 0.95)';
        navbar.style.backdropFilter = 'blur(10px)';
    } else {
        navbar.style.background = 'var(--primary)';
        navbar.style.backdropFilter = 'none';
    }
});

// View Details button interaction
const viewDetailsButtons = document.querySelectorAll('.view-details');
viewDetailsButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        alert('This is a static demo. Product details would be shown here in a real application.');
    });
});

// Shop Filter Functionality
function initShopFilters() {
    const teamFilter = document.getElementById('team-filter');
    const kitFilter = document.getElementById('kit-type');
    const jerseyItems = document.querySelectorAll('.jersey-item');
    
    function filterJerseys() {
        const selectedTeam = teamFilter.value;
        const selectedKit = kitFilter.value;
        
        jerseyItems.forEach(item => {
            const itemTeam = item.getAttribute('data-team');
            const itemKit = item.getAttribute('data-kit');
            
            const teamMatch = selectedTeam === 'all' || itemTeam === selectedTeam;
            const kitMatch = selectedKit === 'all' || itemKit === selectedKit;
            
            if (teamMatch && kitMatch) {
                item.style.display = 'block';
                setTimeout(() => {
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, 50);
            } else {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.display = 'none';
                }, 300);
            }
        });
    }
    
    if (teamFilter && kitFilter) {
        teamFilter.addEventListener('change', filterJerseys);
        kitFilter.addEventListener('change', filterJerseys);
    }
    
    // Load More functionality
    const loadMoreBtn = document.querySelector('.load-more-button');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            alert('More jerseys would load here in a real application!');
        });
    }
}

// Initialize everything when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Add fade-in animation to elements
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.jersey-card, .feature-item, .jersey-item');
        
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.style.opacity = "1";
                element.style.transform = "translateY(0)";
            }
        });
    };

    // Set initial state for animated elements
    const animatedElements = document.querySelectorAll('.jersey-card, .feature-item, .jersey-item');
    animatedElements.forEach(element => {
        element.style.opacity = "0";
        element.style.transform = "translateY(20px)";
        element.style.transition = "opacity 0.6s ease, transform 0.6s ease";
    });

    // Run on load and scroll
    animateOnScroll();
    window.addEventListener('scroll', animateOnScroll);
    
    // Initialize shop filters if on shop page
    if (window.location.pathname === '/shop' || window.location.pathname === '/shop/') {
        initShopFilters();
    }
});